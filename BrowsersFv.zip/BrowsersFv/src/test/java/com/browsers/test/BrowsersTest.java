package com.browsers.test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import static org.junit.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;


public class BrowsersTest {
	private WebDriver driver;
	By searchBox = By.name("q");
	By videoLocator = By.cssSelector("a[href=\"https://www.youtube.com/watch?v=goaZTAzsLMk\"]");
	
	
	
	  public void googleSearch() {

			WebElement searchbox = driver.findElement(searchBox);
			searchbox.clear();
			searchbox.sendKeys("testing videos");
			searchbox.submit();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			//wait.until(ExpectedConditions.presenceOfElementLocated(videoLocator));
			assertTrue(driver.findElement(videoLocator).isDisplayed());
			System.out.println("Hola :c");
 
	  }
	  @Before
	  
	  
	  @Parameters({"URL", "BrowserType"})
	  public void beforeClass(String url, String browserType) {
		  if (browserType.equalsIgnoreCase("Chrome")) {
			  System.setProperty("webdriver.chrome.driver", "./src/test/resources/resourses/chromedriver100.exe"); //:c
			  driver = new ChromeDriver();
			  
		}else if (browserType.equalsIgnoreCase("Firefox")) {
			System.setProperty("webdriver.gecko.driver", "./src/test/resources/resourses/geckodriver.exe");
			driver = new FirefoxDriver();
			
		}else if (browserType.equalsIgnoreCase("Internet Explorer")) {
			System.setProperty("webdriver.ie.driver", "./src/test/resources/resourses/IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		  
		  System.setProperty("webdriver.chrome.driver", "./src/test/resources/resourses/chromedriver.exe");
		  driver = new ChromeDriver();
		  
		  driver.manage().window().maximize();
		  driver.get(url);
		  System.out.println("Opening:" + browserType);
	  }

}
